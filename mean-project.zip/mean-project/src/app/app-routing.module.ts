import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from "./login/login.component";
import { ProfileComponent } from "./profile/profile.component";
import { CreateUserComponent } from "./create-user/create-user.component";
import { AllRequestsComponent } from "./all-requests/all-requests.component";
import { AllUsersComponent } from "./all-users/all-users.component";
import { ModuleWithProviders } from "@angular/core";
const routes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'login', component: LoginComponent },
  { path: "profile", component: ProfileComponent },
  { path: "createUser", component: CreateUserComponent },
  { path: "allUsers", component: AllUsersComponent },
  { path: "allRequests", component: AllRequestsComponent }
];

export const routing: ModuleWithProviders = RouterModule.forRoot(routes);

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],

})
export class AppRoutingModule { }
