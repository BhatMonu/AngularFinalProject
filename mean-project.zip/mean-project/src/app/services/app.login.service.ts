import { Injectable } from "@angular/core";
import { Http, Response, Headers, RequestOptions } from "@angular/http"
import { Observable } from "rxjs"
import { User } from "./../model/login.model";
import { map } from 'rxjs/operators';
@Injectable()
export class LoginService {
    url: string;
    constructor(private http: Http) {

        this.url = "http://localhost:4070";
    }

    postData(user: User): Observable<Response> {
        console.log("User", user);
        let resp: Observable<Response>;
        let header: Headers = new Headers({ "Content-Type": "application/json" });
        let options: RequestOptions = new RequestOptions();
        options.headers = header;
        resp = this.http.post(`${this.url}/api/users/auth`, JSON.stringify(user), options);
        console.log("resp", JSON.stringify(resp));
        return resp;

    }

    createNewUser(user: User): Observable<Response> {

        let resp: Observable<Response>;
        let header: Headers = new Headers({ "Content-Type": "application/json" });
        let options: RequestOptions = new RequestOptions();
        options.headers = header;
        resp = this.http.post(`${this.url}/api/users/create`, JSON.stringify(user), options);
        console.log("resp", JSON.stringify(resp));
        return resp;
    }


}