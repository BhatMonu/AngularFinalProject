import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router"
import { LoginService } from "./../services/app.login.service";
import { User, CreateUser, CreateUserCredentials } from "./../model/login.model";
import { map } from 'rxjs/operators';
import { Response } from "@angular/http";

@Component({
  selector: 'app-create-user',
  templateUrl: './create-user.component.html',
  styleUrls: ['./create-user.component.css']
})
export class CreateUserComponent implements OnInit {
  createUser: CreateUser;
  createCredentials: CreateUserCredentials;
  constructor() {
    this.createUser = new CreateUser("", "", "", new Date, {}, {}, "", "", "", "", "", "", "", "")
    this.createCredentials = new CreateUserCredentials("", "", "", "", "", "")
  }
  createNewUser(): void {
    if (this.createCredentials.UserName && this.createCredentials.UserID && this.createCredentials.Password && this.createCredentials.Role && this.createCredentials.RoleID) {

    }
  }
  ngOnInit() {
  }

}
