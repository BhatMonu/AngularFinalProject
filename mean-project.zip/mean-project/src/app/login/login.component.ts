
import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router"
import { LoginService } from "./../services/app.login.service";
import { User } from "./../model/login.model";
import { map } from 'rxjs/operators';
import { Response } from "@angular/http";

@Component({
  selector: 'app-login-component',
  templateUrl: './login.component.html'

})
export class LoginComponent implements OnInit {
  user: User;
  authenticated: Boolean;
  // users: Array<User>;
  constructor(private service: LoginService, private router: Router) {
    this.user = new User("", "");
    this.authenticated = false;
    //   this.users = new Array<User>();
  }
  Login(): void {
    let sessToken = "";
    if (this.user.UserName != undefined && this.user.Password != undefined
      && this.user.UserName != "" && this.user.Password != "") {
      this.service.postData(this.user).pipe(map(data => {
        console.log("data", data.json());
        let temp = data.json();
        console.log("final", temp.token);
        this.authenticated = temp.authenticated;
        console.log("authenticated", this.authenticated);

        //new feature of html5 session storage
        sessionStorage.setItem("LoginData", `${temp}`)
        sessionStorage.setItem("authorization", `bearer ${temp.token}`);
        // sessToken = sessionStorage.getItem("authorization");
        // console.log(sessToken);
        if (this.authenticated === true) {
          this.router.navigate(['createUser']);
        } else {
          alert("User doesn't exist");
        }
      })).subscribe();


    } else {
      alert("Please enter username and password to login. If you are a new user please register first.");
      //  this.router.navigate(['profile']);
    }
  }
  ngOnInit(): void { }
}
