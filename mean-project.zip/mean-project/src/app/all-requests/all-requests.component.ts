import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-all-requests',
  templateUrl: './all-requests.component.html',
  styleUrls: ['./all-requests.component.css']
})
export class AllRequestsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
