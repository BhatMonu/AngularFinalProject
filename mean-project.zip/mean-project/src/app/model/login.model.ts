export class User {
    constructor(public UserName: String,
        public Password: String) {
    }
}

export class CreateUser {
    constructor(
        public PersonalUniqueID: String,
        public Gender: String,
        public Age: String,
        public DateOfBirth: Date,
        public FullName: Object,
        public Address: Object,
        public City: String,
        public State: String,
        public PhoneNo: String,
        public MaritalStatus: String,
        public EducationStatus: String,
        public BirthSign: String,
        public PhysicalDisability: String,
        public PinCode: String
    ) {
    }
}

export class CreateUserCredentials {
    constructor(
        public UserID: String,
        public UserName: String,
        public EmailAddress: String,
        public Password: String,
        public Role: String,
        public RoleID: String
    ) {
    }
}